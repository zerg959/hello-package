def main():
    print("Hello!")

if __name__ == '__main__':
    main()
